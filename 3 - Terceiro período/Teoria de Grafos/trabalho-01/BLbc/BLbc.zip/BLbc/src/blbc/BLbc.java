package blbc;

public class BLbc extends Vertice{
    public static void main(String[] args) {   
       new Interface();   
    }
}